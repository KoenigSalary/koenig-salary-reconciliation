import pandas as pd
import os
from datetime import datetime
import numpy as np

class EnhancedReconciliation:
    def __init__(self):
        # Branch mapping for Koenig Solutions locations
        self.branch_mapping = {
            'gurgaon': 'Gurgaon',
            'dehradun': 'Dehradun', 
            'goa': 'Goa',
            'chennai': 'Chennai',
            'bangalore': 'Bangalore'
        }
        self.default_branch = 'Delhi'
    
    def map_employee_to_branch(self, location):
        """Map employee location to branch"""
        if not location or pd.isna(location):
            return self.default_branch
            
        location_lower = str(location).lower().strip()
        
        # Check for branch keywords in location
        for key, branch in self.branch_mapping.items():
            if key in location_lower:
                return branch
                
        return self.default_branch
    
    def reconcile_salary_and_bank(self, salary_file, bank_files):
        """Enhanced version of your existing reconciliation logic"""
        print("📊 Loading salary data...")
        salary_df = pd.read_excel(salary_file)
        
        # Detect location column
        location_column = self.detect_location_column(salary_df)
        
        # Add branch mapping
        if location_column:
            print(f"📍 Using '{location_column}' column for branch mapping")
            salary_df['Branch'] = salary_df[location_column].apply(self.map_employee_to_branch)
        else:
            print("⚠️ No location column found, assigning all employees to Delhi")
            salary_df['Branch'] = self.default_branch
        
        # Initialize reconciliation status columns
        salary_df['Bank_Match_Status'] = 'Pending'
        salary_df['Bank_Discrepancy'] = ''
        salary_df['Reconciliation_Notes'] = ''
        
        discrepancies = []
        matched_count = 0
        
        # Process each bank file
        for bank_file in bank_files:
            if bank_file and os.path.exists(bank_file):
                print(f"🏦 Processing bank file: {os.path.basename(bank_file)}")
                bank_df = pd.read_excel(bank_file)
                
                # Your existing reconciliation logic - enhanced
                for idx, salary_row in salary_df.iterrows():
                    employee_id = salary_row.get('Employee ID', salary_row.get('Employee_ID', ''))
                    salary_payable = salary_row.get('Salary Payable', salary_row.get('Net_Salary', 0))
                    
                    # Find matching bank record
                    bank_row = bank_df[bank_df['Employee ID'] == employee_id] if 'Employee ID' in bank_df.columns else pd.DataFrame()
                    
                    if not bank_row.empty:
                        bank_salary = bank_row['Salary Paid'].values[0] if 'Salary Paid' in bank_row.columns else 0
                        
                        # Check for discrepancy (your existing logic)
                        if abs(salary_payable - bank_salary) > 0.01:
                            discrepancy_msg = f"Salary mismatch: Expected ₹{salary_payable:,.2f}, Paid ₹{bank_salary:,.2f}"
                            discrepancies.append({
                                'Employee_ID': employee_id,
                                'Employee_Name': salary_row.get('Employee Name', salary_row.get('Name', '')),
                                'Branch': salary_row['Branch'],
                                'Discrepancy': discrepancy_msg,
                                'Expected_Amount': salary_payable,
                                'Actual_Amount': bank_salary,
                                'Difference': salary_payable - bank_salary
                            })
                            
                            # Update salary dataframe
                            salary_df.at[idx, 'Bank_Match_Status'] = 'Discrepancy'
                            salary_df.at[idx, 'Bank_Discrepancy'] = discrepancy_msg
                            salary_df.at[idx, 'Reconciliation_Notes'] = f"Amount difference: ₹{abs(salary_payable - bank_salary):,.2f}"
                        else:
                            # Match found
                            salary_df.at[idx, 'Bank_Match_Status'] = 'Matched'
                            salary_df.at[idx, 'Reconciliation_Notes'] = 'Amount matched with bank'
                            matched_count += 1
                    else:
                        # Employee not found in bank
                        discrepancy_msg = f"Employee not found in Bank SOA"
                        discrepancies.append({
                            'Employee_ID': employee_id,
                            'Employee_Name': salary_row.get('Employee Name', salary_row.get('Name', '')),
                            'Branch': salary_row['Branch'],
                            'Discrepancy': discrepancy_msg,
                            'Expected_Amount': salary_payable,
                            'Actual_Amount': 0,
                            'Difference': salary_payable
                        })
                        
                        salary_df.at[idx, 'Bank_Match_Status'] = 'Not Found'
                        salary_df.at[idx, 'Bank_Discrepancy'] = discrepancy_msg
                        salary_df.at[idx, 'Reconciliation_Notes'] = 'Employee not found in bank records'
        
        return salary_df, discrepancies, matched_count
    
    def detect_location_column(self, df):
        """Detect which column contains location information"""
        possible_columns = ['Location', 'Branch', 'Office', 'City', 'location', 'branch', 'office']
        
        # Check for exact column name matches
        for col in possible_columns:
            if col in df.columns:
                return col
        
        # Check last few columns for location data
        last_cols = df.columns[-5:] if len(df.columns) > 5 else df.columns
        for col in reversed(last_cols):
            if df[col].dtype == 'object' and df[col].notna().sum() > len(df) * 0.5:
                # Check if column contains city-like values
                sample_values = df[col].dropna().head(10).astype(str).str.lower()
                for value in sample_values:
                    for branch_key in self.branch_mapping.keys():
                        if branch_key in value:
                            return col
        
        return None
    
    def generate_branch_summary(self, salary_df):
        """Generate branch-wise summary"""
        summary = salary_df.groupby('Branch').agg({
            'Employee ID': 'count',
            'Salary Payable': 'sum',
            'Bank_Match_Status': lambda x: (x == 'Matched').sum(),
            'Branch': 'first'  # Keep branch name
        }).reset_index()
        
        summary.columns = ['Branch', 'Total_Employees', 'Total_Salary', 'Matched_Employees', 'Branch_Name']
        summary['Discrepancies'] = summary['Total_Employees'] - summary['Matched_Employees']
        summary['Match_Rate_%'] = round((summary['Matched_Employees'] / summary['Total_Employees']) * 100, 2)
        summary['Avg_Salary'] = round(summary['Total_Salary'] / summary['Total_Employees'], 2)
        
        return summary[['Branch', 'Total_Employees', 'Total_Salary', 'Avg_Salary', 'Matched_Employees', 'Discrepancies', 'Match_Rate_%']]
    
    def generate_integrated_report(self, salary_file, bank_files, output_prefix="Enhanced_Salary_Reconciliation"):
        """Generate comprehensive reconciliation report with multiple tabs"""
        
        print("🚀 Starting Enhanced Reconciliation Process...")
        
        # Perform reconciliation
        salary_df, discrepancies, matched_count = self.reconcile_salary_and_bank(salary_file, bank_files)
        
        # Generate summaries
        branch_summary = self.generate_branch_summary(salary_df)
        
        # Create discrepancy dataframe
        discrepancy_df = pd.DataFrame(discrepancies)
        
        # Generate overall statistics
        total_employees = len(salary_df)
        total_discrepancies = len(discrepancies)
        match_rate = round((matched_count / total_employees) * 100, 2)
        total_salary = salary_df['Salary Payable'].sum() if 'Salary Payable' in salary_df.columns else 0
        
        # Create output filename
        timestamp = datetime.now().strftime('%B_%Y')
        output_file = f"{output_prefix}_{timestamp}.xlsx"
        
        print(f"📝 Generating integrated Excel report...")
        
        # Create Excel file with multiple tabs
        with pd.ExcelWriter(output_file, engine='openpyxl') as writer:
            # Tab 1: Enhanced Salary Data with reconciliation status
            salary_df.to_excel(writer, sheet_name='Salary_Data_With_Status', index=False)
            
            # Tab 2: Branch Summary
            branch_summary.to_excel(writer, sheet_name='Branch_Summary', index=False)
            
            # Tab 3: Discrepancies Details
            if not discrepancy_df.empty:
                discrepancy_df.to_excel(writer, sheet_name='Discrepancies', index=False)
            
            # Tab 4: Overall Summary
            summary_data = {
                'Metric': [
                    'Total Employees',
                    'Total Salary Amount',
                    'Matched Records',
                    'Discrepancies',
                    'Match Rate (%)',
                    'Total Branches',
                    'Report Generated On'
                ],
                'Value': [
                    total_employees,
                    f"₹{total_salary:,.2f}",
                    matched_count,
                    total_discrepancies,
                    f"{match_rate}%",
                    len(branch_summary),
                    datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                ]
            }
            summary_df = pd.DataFrame(summary_data)
            summary_df.to_excel(writer, sheet_name='Overall_Summary', index=False)
            
            # Tab 5: Branch-wise Discrepancy Breakdown
            if not discrepancy_df.empty:
                branch_disc = discrepancy_df.groupby('Branch').agg({
                    'Employee_ID': 'count',
                    'Difference': 'sum'
                }).reset_index()
                branch_disc.columns = ['Branch', 'Discrepancy_Count', 'Total_Amount_Difference']
                branch_disc.to_excel(writer, sheet_name='Branch_Discrepancies', index=False)
        
        # Print summary
        print(f"\n✅ Enhanced Reconciliation Completed!")
        print(f"📄 Report saved: {output_file}")
        print(f"\n📊 RECONCILIATION SUMMARY:")
        print("="*60)
        print(f"Total Employees: {total_employees}")
        print(f"Matched Records: {matched_count}")
        print(f"Discrepancies: {total_discrepancies}")
        print(f"Match Rate: {match_rate}%")
        print(f"\n📍 BRANCH-WISE BREAKDOWN:")
        print("-"*60)
        
        for _, row in branch_summary.iterrows():
            print(f"{row['Branch']:12} | {row['Total_Employees']:3d} emp | ₹{row['Total_Salary']:8,.0f} | {row['Discrepancies']:2d} issues | {row['Match_Rate_%']:5.1f}% match")
        
        # Print discrepancies if any
        if discrepancies:
            print(f"\n⚠️  DISCREPANCIES FOUND:")
            print("-"*60)
            for i, disc in enumerate(discrepancies[:5], 1):  # Show first 5
                print(f"{i}. {disc['Employee_ID']} ({disc['Branch']}): {disc['Discrepancy']}")
            
            if len(discrepancies) > 5:
                print(f"... and {len(discrepancies)-5} more discrepancies")
        
        return output_file, {
            'total_employees': total_employees,
            'matched_count': matched_count,
            'total_discrepancies': total_discrepancies,
            'match_rate': match_rate,
            'branch_summary': branch_summary,
            'discrepancies': discrepancies
        }

# Enhanced main function - replaces your existing code
def main():
    """Main function to run enhanced reconciliation"""
    
    # Initialize enhanced reconciliation
    reconciler = EnhancedReconciliation()
    
    # File paths - update these with your actual file paths
    salary_file = "Salary_Sheet_June_2025.xls"  # Your downloaded salary file
    bank_files = [
        "SOA_KotakOD0317_01-Jul-2025_to_26-Jul-2025.xlsx",     # Your Kotak bank file
        "SOA_DeutscheOD100008_01-Jul-2025_to_26-Jul-2025.xlsx" # Your Deutsche bank file
    ]
    
    # Check if files exist
    if not os.path.exists(salary_file):
        print(f"❌ Salary file not found: {salary_file}")
        return
    
    existing_bank_files = [f for f in bank_files if os.path.exists(f)]
    if not existing_bank_files:
        print("❌ No bank files found")
        return
    
    print(f"✅ Found salary file: {salary_file}")
    print(f"✅ Found bank files: {[os.path.basename(f) for f in existing_bank_files]}")
    
    # Run enhanced reconciliation
    try:
        output_file, summary = reconciler.generate_integrated_report(salary_file, existing_bank_files)
        
        print(f"\n🎉 Reconciliation completed successfully!")
        print(f"📁 Open the file: {output_file}")
        
        return output_file, summary
        
    except Exception as e:
        print(f"❌ Error during reconciliation: {e}")
        import traceback
        traceback.print_exc()

# Run the enhanced reconciliation
if __name__ == "__main__":
    result = main()