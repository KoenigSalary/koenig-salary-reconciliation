import streamlit as st
import pandas as pd
import sqlite3
import hashlib
import os
from datetime import datetime, timedelta
import subprocess
import sys
from pathlib import Path
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication

# Page Configuration
st.set_page_config(
    page_title="Koenig Solutions - Salary Management",
    page_icon="💼",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Database Setup
def init_database():
    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            role TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            last_login TIMESTAMP,
            active BOOLEAN DEFAULT 1
        )
    ''')
    
    # Create default admin user
    admin_password = hashlib.sha256("admin123".encode()).hexdigest()
    cursor.execute('''
        INSERT OR IGNORE INTO users (username, password, role) 
        VALUES (?, ?, ?)
    ''', ("admin", admin_password, "Super Admin"))
    
    conn.commit()
    conn.close()

# Authentication Functions
def authenticate_user(username, password):
    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()
    
    hashed_password = hashlib.sha256(password.encode()).hexdigest()
    cursor.execute('''
        SELECT id, username, role FROM users 
        WHERE username = ? AND password = ? AND active = 1
    ''', (username, hashed_password))
    
    user = cursor.fetchone()
    
    if user:
        # Update last login
        cursor.execute('''
            UPDATE users SET last_login = CURRENT_TIMESTAMP 
            WHERE id = ?
        ''', (user[0],))
        conn.commit()
    
    conn.close()
    return user

def get_user_role(username):
    if 'user_info' in st.session_state:
        return st.session_state.user_info[2]
    return None

# File Operations
def get_latest_files():
    download_dir = Path("/Users/praveenchaudhary/Downloads/Koenig-Management-Agent")
    files = {
        'salary': None,
        'tds': None,
        'bank_soa': None
    }
    
    if download_dir.exists():
        # Find latest salary file
        salary_files = list(download_dir.glob("Salary_Sheet_*.xls*"))
        if salary_files:
            files['salary'] = max(salary_files, key=lambda x: x.stat().st_mtime)
        
        # Find latest TDS file
        tds_files = list(download_dir.glob("TDS_Report_*.xlsx"))
        if tds_files:
            files['tds'] = max(tds_files, key=lambda x: x.stat().st_mtime)
        
        # Find latest Bank SOA file
        bank_files = list(download_dir.glob("Bank_SOA_*.xlsx"))
        if bank_files:
            files['bank_soa'] = max(bank_files, key=lambda x: x.stat().st_mtime)
    
    return files

# Main Dashboard Components
def show_login():
    st.title("🔐 Koenig Solutions Login")
    
    col1, col2, col3 = st.columns([1, 2, 1])
    
    with col2:
        with st.form("login_form"):
            st.subheader("Please login to continue")
            username = st.text_input("Username")
            password = st.text_input("Password", type="password")
            login_button = st.form_submit_button("Login", use_container_width=True)
            
            if login_button:
                user = authenticate_user(username, password)
                if user:
                    st.session_state.authenticated = True
                    st.session_state.user_info = user
                    st.success(f"Welcome {user[1]}! ({user[2]})")
                    st.rerun()
                else:
                    st.error("Invalid credentials. Please try again.")
        
        with st.expander("Default Credentials"):
            st.info("Username: admin | Password: admin123")

def show_dashboard():
    user_role = get_user_role(st.session_state.user_info[1])
    
    # Sidebar
    with st.sidebar:
        st.image("https://via.placeholder.com/200x80/4f46e5/ffffff?text=KOENIG", width=200)
        st.title("Navigation")
        
        menu_options = ["📊 Dashboard", "📁 File Management", "🔄 Reconciliation"]
        
        if user_role in ["Super Admin", "Admin"]:
            menu_options.extend(["👥 User Management", "📧 Email Config", "⚙️ Settings"])
        
        selected = st.selectbox("Select Page", menu_options)
        
        st.divider()
        st.write(f"**Logged in as:** {st.session_state.user_info[1]}")
        st.write(f"**Role:** {st.session_state.user_info[2]}")
        
        if st.button("Logout", use_container_width=True):
            for key in list(st.session_state.keys()):
                del st.session_state[key]
            st.rerun()
    
    # Main Content
    if selected == "📊 Dashboard":
        show_main_dashboard()
    elif selected == "📁 File Management":
        show_file_management()
    elif selected == "🔄 Reconciliation":
        show_reconciliation()
    elif selected == "👥 User Management" and user_role in ["Super Admin", "Admin"]:
        show_user_management()
    elif selected == "📧 Email Config" and user_role in ["Super Admin", "Admin"]:
        show_email_config()
    elif selected == "⚙️ Settings" and user_role in ["Super Admin", "Admin"]:
        show_settings()

def show_main_dashboard():
    st.title("📊 Koenig Solutions Dashboard")
    
    # File Status Cards
    files = get_latest_files()
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        status = "✅ Available" if files['salary'] else "❌ Missing"
        st.metric("Salary Sheet", status, 
                 delta=files['salary'].name if files['salary'] else "No file found")
    
    with col2:
        status = "✅ Available" if files['tds'] else "❌ Missing"
        st.metric("TDS Report", status,
                 delta=files['tds'].name if files['tds'] else "No file found")
    
    with col3:
        status = "✅ Available" if files['bank_soa'] else "❌ Missing"
        st.metric("Bank SOA", status,
                 delta=files['bank_soa'].name if files['bank_soa'] else "No file found")
    
    st.divider()
    
    # Quick Actions
    st.subheader("🚀 Quick Actions")
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        if st.button("📥 Download Latest Data", use_container_width=True):
            with st.spinner("Downloading data..."):
                try:
                    result = subprocess.run([sys.executable, "main.py"], 
                                          capture_output=True, text=True)
                    if result.returncode == 0:
                        st.success("Data downloaded successfully!")
                    else:
                        st.error(f"Download failed: {result.stderr}")
                except Exception as e:
                    st.error(f"Error: {str(e)}")
    
    with col2:
        if st.button("🔄 Run Reconciliation", use_container_width=True):
            if all(files.values()):
                with st.spinner("Running reconciliation..."):
                    try:
                        result = subprocess.run([sys.executable, "salary_reconciliation_agent.py"], 
                                              capture_output=True, text=True)
                        if result.returncode == 0:
                            st.success("Reconciliation completed!")
                        else:
                            st.error(f"Reconciliation failed: {result.stderr}")
                    except Exception as e:
                        st.error(f"Error: {str(e)}")
            else:
                st.warning("Please download all required files first")
    
    with col3:
        if st.button("📧 Send Reports", use_container_width=True):
            st.info("Email functionality will be implemented")
    
    with col4:
        if st.button("📈 View Analytics", use_container_width=True):
            st.info("Analytics dashboard coming soon")

def show_file_management():
    st.title("📁 File Management")
    
    # File Upload Section
    st.subheader("📤 Upload Files")
    
    col1, col2 = st.columns(2)
    
    with col1:
        salary_file = st.file_uploader("Upload Salary Sheet", type=['xls', 'xlsx'])
        tds_file = st.file_uploader("Upload TDS Report", type=['xlsx'])
    
    with col2:
        bank_file = st.file_uploader("Upload Bank SOA", type=['xlsx'])
    
    if st.button("Save Uploaded Files"):
        download_dir = Path("/Users/praveenchaudhary/Downloads/Koenig-Management-Agent")
        download_dir.mkdir(exist_ok=True)
        
        saved_files = []
        for file, name in [(salary_file, "Salary_Sheet"), (tds_file, "TDS_Report"), (bank_file, "Bank_SOA")]:
            if file:
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                filename = f"{name}_{timestamp}.{file.name.split('.')[-1]}"
                filepath = download_dir / filename
                
                with open(filepath, "wb") as f:
                    f.write(file.getbuffer())
                saved_files.append(filename)
        
        if saved_files:
            st.success(f"Saved files: {', '.join(saved_files)}")
    
    st.divider()
    
    # Current Files Display
    st.subheader("📋 Current Files")
    files = get_latest_files()
    
    for file_type, file_path in files.items():
        if file_path:
            col1, col2, col3 = st.columns([3, 1, 1])
            with col1:
                st.write(f"**{file_type.replace('_', ' ').title()}:** {file_path.name}")
            with col2:
                st.write(f"Modified: {datetime.fromtimestamp(file_path.stat().st_mtime).strftime('%Y-%m-%d %H:%M')}")
            with col3:
                if st.button(f"Delete", key=f"del_{file_type}"):
                    try:
                        file_path.unlink()
                        st.success(f"Deleted {file_path.name}")
                        st.rerun()
                    except Exception as e:
                        st.error(f"Error deleting file: {str(e)}")

def show_reconciliation():
    st.title("🔄 Reconciliation Center")
    
    files = get_latest_files()
    
    if not all(files.values()):
        st.warning("⚠️ Missing required files. Please upload all files before reconciliation.")
        missing = [k for k, v in files.items() if not v]
        st.write("Missing files:", ", ".join(missing))
        return
    
    st.success("✅ All required files are available")
    
    # Reconciliation Options
    st.subheader("🎯 Reconciliation Options")
    
    col1, col2 = st.columns(2)
    
    with col1:
        reconciliation_type = st.selectbox(
            "Select Reconciliation Type",
            ["Full Reconciliation", "Salary vs TDS", "Bank vs Salary", "Branch Analysis Only"]
        )
    
    with col2:
        branch_filter = st.multiselect(
            "Filter by Branch",
            ["Gurgaon", "Dehradun", "Goa", "Chennai", "Bangalore", "Delhi"],
            default=["Gurgaon", "Dehradun", "Goa", "Chennai", "Bangalore", "Delhi"]
        )
    
    # Advanced Options
    with st.expander("🔧 Advanced Options"):
        tolerance = st.number_input("Amount Tolerance (₹)", min_value=0.0, value=1.0, step=0.1)
        include_inactive = st.checkbox("Include Inactive Employees")
        detailed_report = st.checkbox("Generate Detailed Report", value=True)
    
    if st.button("🚀 Start Reconciliation", use_container_width=True):
        with st.spinner("Processing reconciliation..."):
            # Here you would call your reconciliation logic
            st.success("✅ Reconciliation completed successfully!")
            
            # Display sample results
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric("Total Employees", "150", delta="5 new")
            with col2:
                st.metric("Matched Records", "145", delta="96.7%")
            with col3:
                st.metric("Discrepancies", "5", delta="-2")
            
            # Sample reconciliation data
            sample_data = pd.DataFrame({
                'Employee': ['John Doe', 'Jane Smith', 'Bob Johnson'],
                'Branch': ['Gurgaon', 'Delhi', 'Bangalore'],
                'Salary': [50000, 60000, 55000],
                'TDS': [5000, 6000, 5500],
                'Status': ['Matched', 'Matched', 'Discrepancy']
            })
            
            st.subheader("📊 Reconciliation Results")
            st.dataframe(sample_data, use_container_width=True)

def show_user_management():
    st.title("👥 User Management")
    
    # Add New User
    with st.expander("➕ Add New User"):
        with st.form("add_user"):
            col1, col2 = st.columns(2)
            with col1:
                new_username = st.text_input("Username")
                new_role = st.selectbox("Role", ["User", "Admin", "Viewer"])
            with col2:
                new_password = st.text_input("Password", type="password")
                confirm_password = st.text_input("Confirm Password", type="password")
            
            if st.form_submit_button("Add User"):
                if new_password == confirm_password:
                    # Add user logic here
                    st.success(f"User {new_username} added successfully!")
                else:
                    st.error("Passwords do not match")
    
    # User List
    st.subheader("👤 Current Users")
    sample_users = pd.DataFrame({
        'Username': ['admin', 'hr_manager', 'accountant'],
        'Role': ['Super Admin', 'Admin', 'User'],
        'Last Login': ['2024-01-15 10:30', '2024-01-14 16:45', '2024-01-13 09:15'],
        'Status': ['Active', 'Active', 'Active']
    })
    
    st.dataframe(sample_users, use_container_width=True)

def show_email_config():
    st.title("📧 Email Configuration")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("SMTP Settings")
        smtp_server = st.text_input("SMTP Server", value="smtp-mail.outlook.com")
        smtp_port = st.number_input("SMTP Port", value=587)
        email = st.text_input("Email Address")
        password = st.text_input("Password", type="password")
    
    with col2:
        st.subheader("Schedule Settings")
        epf_day = st.number_input("EPF Reminder Day", min_value=1, max_value=31, value=25)
        recon_day = st.number_input("Reconciliation Day", min_value=1, max_value=31, value=26)
        
        st.subheader("Recipients")
        recipients = st.text_area("Email Recipients (one per line)")
    
    if st.button("💾 Save Configuration"):
        st.success("Email configuration saved successfully!")

def show_settings():
    st.title("⚙️ System Settings")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("🗂️ File Paths")
        download_path = st.text_input("Download Directory", value="/Users/praveenchaudhary/Downloads/Koenig-Management-Agent")
        backup_path = st.text_input("Backup Directory")
        
        st.subheader("🏢 Branch Configuration")
        branches = st.text_area("Branches (one per line)", value="Gurgaon\nDehradun\nGoa\nChennai\nBangalore\nDelhi")
    
    with col2:
        st.subheader("🔧 System Preferences")
        auto_download = st.checkbox("Auto Download on Login")
        auto_backup = st.checkbox("Auto Backup Files")
        debug_mode = st.checkbox("Enable Debug Mode")
        
        st.subheader("🎨 UI Settings")
        theme = st.selectbox("Theme", ["Light", "Dark", "Auto"])
        language = st.selectbox("Language", ["English", "Hindi"])
    
    if st.button("💾 Save Settings"):
        st.success("Settings saved successfully!")

# Main Application
def main():
    init_database()
    
    # Custom CSS
    st.markdown("""
    
    """, unsafe_allow_html=True)
    
    if 'authenticated' not in st.session_state:
        st.session_state.authenticated = False
    
    if not st.session_state.authenticated:
        show_login()
    else:
        show_dashboard()

if __name__ == "__main__":
    main()
                
